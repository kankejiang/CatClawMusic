---
name: maui-android-crash-debugger
description: This skill should be used when a .NET MAUI Android app crashes at startup or during page navigation, especially with errors like "Unable to resolve service for type", "StaticResource not found", missing image assets, or XAML parse exceptions. It guides WorkBuddy through a systematic check of DI registrations, XAML resources, image references, Shell routes, and ViewModel bindings, then validates with a dotnet build.
agent_created: true
---

# MAUI Android Crash Debugger

## Overview

Systematically diagnose and fix common .NET MAUI Android startup/navigation crashes. The workflow checks dependency injection, XAML resources, image references, Shell routes, and ViewModel bindings, then verifies with a `dotnet build` for Android.

## When to Use This Skill

Use this skill when the user reports any of the following in a .NET MAUI Android project:

- `System.InvalidOperationException: Cannot determine property to provide the value for`
- `Microsoft.Maui.Controls.Xaml.XamlParseException: StaticResource not found for key ...`
- `Unable to resolve service for type '...ViewModel' while attempting to activate '...Page'`
- Missing image/asset warnings or exceptions (e.g. `music_note.png` not found)
- Shell navigation failures (`RelativeBindingSource`, route not found, etc.)
- Page crashes when tabs or settings items are tapped

## Workflow

### Step 1: Reproduce and Identify the Crash Type

1. Read the latest exception or build log provided by the user.
2. Classify the crash into one of these categories:
   - DI resolution failure
   - XAML resource/converter failure
   - Missing image/icon asset
   - Shell route missing
   - ViewModel binding missing property

### Step 2: Check Dependency Injection Registrations

1. Open `MauiProgram.cs`.
2. Verify every page constructor parameter is registered in `builder.Services`:
   - ViewModels used by pages (`AddSingleton`, `AddTransient`, etc.)
   - Core services (`PlayQueue`, `MusicDatabase`, `ILyricsService`, etc.)
   - Platform services (`IAudioPlayerService`)
3. If a ViewModel is missing, add the appropriate registration and rebuild.

### Step 3: Check XAML Resources and Converters

1. If the error mentions `StaticResource not found`, identify the missing key.
2. Check `Resources/Styles/Colors.xaml` or `Styles.xaml` for converter/resource registrations.
3. Create the missing converter in `Converters/` and register it as a resource with `x:Key`.
4. Ensure `AppThemeBinding` is used inside `Style` setters, not as standalone resources.

### Step 4: Fix Image/Icon References

1. List actual image assets under `Resources/Images/` using `Glob`.
2. Search XAML and C# for `.png` references.
3. For MAUI `MauiImage` assets (especially SVGs), reference them **without file extension** (e.g. `ic_search`, not `ic_search.png`).
4. Replace references to non-existent PNGs with existing SVG or PNG equivalents.
5. Common fallback mapping:
   - `music_note.png` → `ic_music_note`
   - `play_circle.png` → `ic_play`
   - `search.png` → `ic_search`
   - `settings.png` → `ic_settings`

### Step 5: Register Shell Routes for Missing Pages

1. Open `AppShell.xaml` and the code-behind of the page that triggers navigation.
2. If the page navigates to a route not declared in `AppShell`, either:
   - Create the target page and add a `<ShellContent Route="..." ContentTemplate="{DataTemplate pages:TargetPage}" />`
   - Or redirect to an existing page temporarily.
3. Register the new page in `MauiProgram.cs` as `AddTransient<Pages.TargetPage>()` if it has constructor injection.

### Step 6: Fix ViewModel Binding Properties

1. Search XAML for bindings that may fail because a property does not exist.
2. Add the missing observable property to the ViewModel using `[ObservableProperty]` (CommunityToolkit.Mvvm) or a manual property change notification.
3. Initialize collections to empty instances rather than `null` to avoid `CollectionView` crashes.

### Step 7: Verify with a Build

1. Run `dotnet build <MauiProject>.csproj -f net10.0-android` (adjust framework as needed).
2. If environment variables or SDK paths are required, pass them with `-p:AndroidSdkDirectory=...` and `-p:JavaSdkDirectory=...`.
3. Ensure the build reports **0 errors**. Warnings about obsolete APIs (`Frame`, `LayoutOptions.FillAndExpand`, `DisplayAlert`) are usually acceptable but should be noted.
4. If the user has a convention to publish APKs after significant changes, ask before proceeding or configure the publish target first.

## Common Fixes Reference

| Symptom | Likely Cause | Fix |
|---------|-------------|-----|
| `Cannot determine property to provide the value for` | `AppThemeBinding` used as standalone resource | Move `AppThemeBinding` into `Style` setter `Value` |
| `StaticResource not found for key X` | Converter/resource not registered | Create converter and register in `Colors.xaml`/`Styles.xaml` |
| `Unable to resolve service for type '...ViewModel'` | Missing DI registration | Add `AddTransient<ViewModel>()` in `MauiProgram.cs` |
| Missing image at runtime | Referencing PNG that doesn't exist or using extension for SVG | Use existing SVG name without extension |
| Shell route not found | Route not registered in `AppShell.xaml` | Add `<ShellContent Route="..." ... />` |
| Binding property not found | ViewModel missing property | Add `[ObservableProperty]` property |

## Resources

- `references/maui_common_fixes.md` — detailed reference for specific MAUI/Android errors and fixes (optional, to be expanded as new issues are encountered).
